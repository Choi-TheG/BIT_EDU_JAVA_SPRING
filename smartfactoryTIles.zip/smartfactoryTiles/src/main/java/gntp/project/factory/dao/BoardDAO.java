package gntp.project.factory.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import gntp.project.factory.vo.BoardVO;
import gntp.project.factory.vo.GuestbookVO;
import gntp.project.factory.vo.MemberVO;
import gntp.project.factory.vo.ReplyVO;

@Repository("boardDAO")
public class BoardDAO {
	
	@Autowired
	private SqlSession sqlSession;
		
	
	public MemberVO checkMember(String userId, String pwd) {
		MemberVO vo = null;
		Map<String, String> map = new HashMap<String, String>();
		map.put("id", userId);
		map.put("pwd", pwd);
		vo = sqlSession.selectOne("mapper.member.findMember", map);
		return vo;
	}
	
	public ArrayList<BoardVO> selectAll() throws SQLException{
		ArrayList<BoardVO> list = null;
		list = (ArrayList)sqlSession.selectList("selectAllBoardList");
		
		return list;
	}
	
	public BoardVO selectOne(String seq,String token) throws SQLException {
		// TODO Auto-generated method stub
		BoardVO board = null;

		if(token!=null) {
			int affectedCount = sqlSession.update("mapper.board.updateReadCount", Integer.parseInt(seq));
			boolean flag = false;
			if(affectedCount>0) {
				flag = true;
			}
		}
		
		board = (BoardVO)sqlSession.selectOne("mapper.board.selectBoard", 
																	Integer.parseInt(seq));
		System.out.println(board);	
		return board;
	}
/*
	public boolean insertOne(BoardVO book) throws SQLException {
		boolean flag = false;

		int affectedCount = sqlSession.insert("mapper.board.insertBook", book);
		if(affectedCount > 0) {
			flag = true;
		}
		return flag;
	}

	public GuestbookVO selectOneForUpdate(String seq) throws SQLException {
		// TODO Auto-generated method stub
		GuestbookVO book = null;
		book = (GuestbookVO)sqlSession.selectOne("mapper.guestbook.selectBookForUpdate", Integer.parseInt(seq));
		System.out.println(book);
		return book;
	}
	
	

	public boolean updateOne(GuestbookVO book) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;

		int affectedCount = sqlSession.update("mapper.guestbook.updateBook", book);
		if(affectedCount>0) {
			flag = true;
		}
		
		return flag;
	}

	public boolean deleteOne(String seq) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		//connection 연결확인 하세요
		int seqInt = Integer.parseInt(seq);
		int affectedCount = sqlSession.delete("mapper.guestbook.deleteBook", seqInt);
		if(affectedCount>0) {
			flag = true;
		}
		
		return flag;
	}

	public boolean insertReply(ReplyVO vo) throws SQLException {
		// TODO Auto-generated method stub
		boolean flag = false;
		//connection 연결확인 하세요
		int affectedCount = sqlSession.insert("mapper.guestbook.insertReply", vo);
		if(affectedCount>0) {
			flag = true;
		}
		
		return flag;
	}
	
	
	*/
}







