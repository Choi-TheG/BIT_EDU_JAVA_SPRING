package gntp.project.factory.controller;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import gntp.project.factory.service.TestService;
import gntp.project.factory.vo.ReplyVO;

@RestController("testController")
@RequestMapping("/test")
public class TestController {
	
	@Autowired
	private TestService testService;
	
	@RequestMapping(value="/aloha", method=RequestMethod.GET)	// .do
	public String hello() {			// return type, parameter -> Rest는 jquery의 ajax를 이용해 따로 처리하기 때문에 ModelAndView 쓰지않음
		return "Rest aloha~";
	}
	
	@RequestMapping(value="/reply", method=RequestMethod.GET)
	public ReplyVO reply() {
		ReplyVO vo = new ReplyVO(1, "rest test", new Timestamp(System.currentTimeMillis()),2);
		
		
		return vo;
	}
	
	// ArrayList<ReplyVO> 리턴 메소드 생성
	@RequestMapping(value="/list", method=RequestMethod.GET)
	public ArrayList<ReplyVO> list(){
		ArrayList<ReplyVO> list = new ArrayList<ReplyVO>();
		
		for(int i=0;i<5;i++) {
			ReplyVO vo = new ReplyVO();
			vo.setReplySeq(i);
			vo.setReplyContent("choi "+i);
			vo.setReplyDate(new Timestamp(System.currentTimeMillis()));
			vo.setGbSeq(i*10);
			
			list.add(vo);
		}
		return list;
	}
	
	// key = replyList이고 value가 ArrayList<ReplyVO>인 HashMap을 리턴하는 메소드 생성
	@RequestMapping(value="/replyMap", method=RequestMethod.GET)
	public HashMap<String, ArrayList<ReplyVO>> returnList(){
		HashMap<String, ArrayList<ReplyVO>> map = new HashMap<String, ArrayList<ReplyVO>>();
		ArrayList<ReplyVO> list = new ArrayList<ReplyVO>();
		
		for(int i=0;i<5;i++) {
			ReplyVO vo = new ReplyVO();
			vo.setReplySeq(i);
			vo.setReplyContent("choi "+i);
			vo.setReplyDate(new Timestamp(System.currentTimeMillis()));
			vo.setGbSeq(i*10);
			
			list.add(vo);
		}
		map.put("replyList", list);
		return map;
	}
	
	@RequestMapping(value="/viewTestRest", method=RequestMethod.GET)
	public ModelAndView testRest(HttpServletRequest request, 
					HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "testRest";
		
		mav.setViewName(viewName);
		return mav;
	}
	
	
	@RequestMapping(value="/insertReply", method= {RequestMethod.GET,RequestMethod.POST})
	public String insertReply(@RequestBody ReplyVO vo, HttpServletRequest request, 
					HttpServletResponse response) throws Exception {
		vo.setReplyDate(new Timestamp(System.currentTimeMillis()));
		String result = "fail";
		if(vo!=null) {
			result = "success";
		}
		return result;
	}

	@RequestMapping(value="/insertReplyMap", method= {RequestMethod.GET,RequestMethod.POST})
	public HashMap<String, ArrayList<ReplyVO>> insertReplyMap(@RequestBody ReplyVO vo, HttpServletRequest request, 
					HttpServletResponse response) throws Exception {
		vo.setReplyDate(new Timestamp(System.currentTimeMillis()));
		System.out.println(vo);
		HashMap<String, ArrayList<ReplyVO>> map = new HashMap<String, ArrayList<ReplyVO>>();
		ArrayList<ReplyVO> list = new ArrayList<ReplyVO>();
		ReplyVO vo1 = null;
		for(int i=0;i<5;i++) {
			vo1 = new ReplyVO(i, "rest test", new Timestamp(System.currentTimeMillis()),i*10);
			
			list.add(vo1);
		}
		list.add(vo);
		map.put("replyList", list);
		return map;
	}
	
	@RequestMapping(value="/selectReply", method= {RequestMethod.GET,RequestMethod.POST})
	public ReplyVO selectReply(@RequestParam("seq") String seq, HttpServletRequest request, 
					HttpServletResponse response) throws Exception {
		ReplyVO vo = null;
		
		vo = testService.findReply(seq);
		return vo;
	}
	
	
	@RequestMapping(value="/selectReplyEntity", method= {RequestMethod.GET,RequestMethod.POST})
	public ResponseEntity<ReplyVO> selectReplyEntity(@RequestParam("seq") String seq, HttpServletRequest request, 
					HttpServletResponse response) throws Exception {
		ReplyVO vo = null;
		
		vo = testService.findReply(seq);
		return new ResponseEntity<ReplyVO>(vo, HttpStatus.OK);
	}
	
	
	@RequestMapping(value="/test.do", method=RequestMethod.GET)
	public ModelAndView test(HttpServletRequest request, 
					HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		String viewName = "error";
		boolean flag = testService.testService();
		if(flag) {
			viewName = "welcome";
		}
		mav.setViewName(viewName);
		return mav;
	}
}
